package dungeoncrawler.game.entities;


import java.awt.Graphics;

import java.awt.Rectangle;

import javax.swing.SwingUtilities;
import dungeoncrawler.framework.Engine;
import dungeoncrawler.framework.resources.Loader;
import dungeoncrawler.framework.resources.Resources;
import dungeoncrawler.framework.utils.MathHelper;
import dungeoncrawler.game.states.LoseMenu;
import dungeoncrawler.game.states.WinMenu;
import dungeoncrawler.game.world.Tile;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.FileWriter;
import java.io.BufferedWriter;

public class Player extends Entity {

	private static final long serialVersionUID = 1L;

	private int hp;
	private int maxHp;
	private byte regenDelay;
	private int armor;
	private int gold;
	private int chests;
	private int bats;
	private int score;
	private int highscore;
	
	private byte attackTime;
	private byte damageTime;
	private FileWriter writeFile = null;
    private BufferedWriter writer = null;
	
	public Player() {
		super(Resources.PLAYER, MathHelper.randomInt(2, 14), MathHelper.randomInt(2, 7));
		this.hp = 20;
		this.maxHp = 20;
		this.regenDelay = 0;
		this.armor = 0;
		this.gold = 0;
		this.attackTime = 0;
		this.damageTime = 0;
		this.chests = 0;
		this.score = 0;
		this.highscore = GetHighScoreValue();
	}
	public int GetHighScoreValue()
    {
        FileReader readFile = null;
        BufferedReader reader = null;
        try
        {
            readFile = new FileReader("highscore.txt");
            reader = new BufferedReader(readFile);
            int highscore = Integer.parseInt(reader.readLine());
            return highscore;
       }
       catch (Exception e)
       {
           return 0;
       }
       finally
       {
           try
           {
               reader.close();
           }
           catch (IOException e)
           {
               e.printStackTrace();
           }
       }
   }
	public void replaceRandomly() {
		super.x = MathHelper.randomInt(2, 14)*Tile.SIZE;
		super.y = MathHelper.randomInt(2, 7)*Tile.SIZE;
	}

	public int getHp() {
		return hp;
	}
	
	public int getMaxHp() {
		return maxHp;
	}
	public int getBats() {
		return bats;
	}
	
	public void instantHeal(int amount) {
		this.hp += amount;
		if(this.hp > this.maxHp) this.hp = this.maxHp;
	}
	
	public void regenerateHealth() {
		if(this.hp < this.maxHp) this.regenDelay++;
		else this.regenDelay = 0;
		
		if(this.regenDelay == 50) {
			this.hp++;
			this.regenDelay = 0;
		}
	}
	
	public int getArmor() {
		return armor;
	}
	
	public void addArmor(int amount) {
		this.armor += amount;
		this.score += 5*amount;
		if(this.score>this.highscore)
        {
            highscore=score;
            try
            {
                writeFile = new FileWriter("highscore.txt");
                writer = new BufferedWriter(writeFile);
                writer.write(Integer.toString(highscore));
                writer.close();
            }
            catch (Exception e)
            {
                //errors
            }
        }
		if(this.armor > 75) this.armor = 75;
	}
	
	public int getGold() {
		return gold;
	}
	public int getChests() {
		return chests;
	}
	public int getScore() {
		return score;
	}
	public int getHighScore() {
		return highscore;
	}
	
	public void giveGold(int amount) {
		this.gold += amount;
		this.score += 10*amount;
		if(this.score>this.highscore)
        {
            highscore=score;
            try
            {
                writeFile = new FileWriter("highscore.txt");
                writer = new BufferedWriter(writeFile);
                writer.write(Integer.toString(highscore));
                writer.close();
            }
            catch (Exception e)
            {
                //errors
            }
        }
	}
	public void addChest() {
		this.chests++;
		if (this.chests > 11) {
			WinMenu.setScore(this.score);
			WinMenu.setHighscore(this.highscore);
			SwingUtilities.invokeLater(new Runnable() {
				@Override
				public void run() {
					Loader.load();
					Engine.init();
					Engine.win();
				}
			});
		}
	}
	public void addBats() {
		this.bats++;
		this.score+=10;
		if(this.score>this.highscore)
        {
            highscore=score;
            try
            {
                writeFile = new FileWriter("highscore.txt");
                writer = new BufferedWriter(writeFile);
                writer.write(Integer.toString(highscore));
                writer.close();
            }
            catch (Exception e)
            {
                //errors
            }
        }
	}
	
	@Override
	public void move() {
		if(this.attackTime == 0) {
			super.move();
			switch(super.facing) {
			case NORTH: super.entityID = Resources.PLAYER_BACK; break;
			case SOUTH: super.entityID = Resources.PLAYER; break;
			case WEST: super.entityID = Resources.PLAYER_LEFT; break;
			case EAST: super.entityID = Resources.PLAYER_RIGHT; break;
			}
		}
	}
	
	public void decreaseTime() {
		if(this.attackTime > 0) this.attackTime--;
		if(this.damageTime > 0) this.damageTime--;
	}
	
	public void attack() {
		if(this.attackTime == 0) this.attackTime = 30;
	}
	
	public Rectangle getAttackBox() {
		if(this.attackTime == 20) {
			switch(super.facing) {
			case NORTH:
				return new Rectangle(super.x, super.y - super.height, super.width, super.height);
			case SOUTH:
				return new Rectangle(super.x, super.y + super.height, super.width, super.height);
			case WEST:
				return new Rectangle(super.x - super.width, super.y, super.width, super.height);
			case EAST:
				return new Rectangle(super.x + super.width, super.y, super.width, super.height);
			default:
				break;
			}
		}
		return new Rectangle(0, 0, 0, 0);
	}
	
	@Override
	public void render(Graphics graphics) {
		if((up || down || left || right) && this.attackTime == 0) {
			super.animationDelay++;
			if(super.animationDelay == 70) {
				super.animationDelay = 0;
				super.animationFrame = (byte) (1 - super.animationFrame);
			}
		}
		graphics.drawImage(Resources.TEXTURES.get(entityID + animationFrame), x+5, y+5, width-10, height-10, null);
	}
	
	public void damage(int amount) {
		if(this.damageTime == 0) {
			this.hp -= amount;
			this.damageTime = 50;
		}
		if(this.hp<0) {
			LoseMenu.setScore(this.score);
			LoseMenu.setHighscore(this.highscore);
			SwingUtilities.invokeLater(new Runnable() {
				@Override
				public void run() {
					Loader.load();
					Engine.init();
					Engine.end();
				}
			});
		}
	}
}
