package dungeoncrawler.framework.utils;

public interface FunctionalInterface {

	public void action();
}
